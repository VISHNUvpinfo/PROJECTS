import sys
import command_pallet as cp
actions = ["add","ls","del","done","help","report"]
if len(sys.argv) == 1:
    cp.help_todo()
elif sys.argv[1] in actions:
    command_todo = sys.argv[1]
    if actions.index(command_todo) == 0:
        cp.add_todo()
    elif actions.index(command_todo) == 1:
        cp.ls_todo()
    elif actions.index(command_todo) == 2:
        cp.del_todo()
    elif actions.index(command_todo) == 3:
        cp.done_todo()
    elif actions.index(command_todo) == 4:
        cp.help_todo()
    elif actions.index(command_todo) == 5:
        cp.report_todo()
else:
    print("Invalid command")
    