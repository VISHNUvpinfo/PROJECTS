#Importing required packages for command_pallet
import sys
import os
from datetime import datetime
 #This function returns the content of the existing file and if there is no file it creates new one
def readtxt(file):
    try:
        reader = open(file, "r+")
        content_inside = reader.readlines()
        reader.close()
        return content_inside
    except:
        sys.stdout.write("There are no pending todos!")
        return "00"
 #This function gets input from command-line save in 'todo.txt' file
def add_todo():
    try:
        if sys.argv[2] == "":
            sys.stdout.write("Error : Missing todo string. Nothing added!")
        else:
            temp = " ".join(sys.argv[2:])
            todofile = open('todo.txt',"a+")
            todofile.writelines(temp)
            todofile.write('\n')
            todofile.close()
            sys.stdout.write("Added todo: \"{}\"".format(temp))
    except:
        sys.stdout.write("Error: Missing todo string. Nothing added!")
#This function basically display the content in 'todo.txt' file
def ls_todo(): 
    contant_todo = readtxt('todo.txt')
    if contant_todo == "00":
        pass
    else:
        contant_todo.reverse()
        k=len(contant_todo)
        l=0
        for i in contant_todo:
            if k == 0:
                break
            else:
                stuff ="[{}] {}".format(k,contant_todo[l])
                more_stuff = list(stuff.strip(" "))
                sys.stdout.write("".join(more_stuff))
                k,l=k-1,l+1
#This is an template function deleting task and for mark as done task
def del_temp(): 
    contant_todo = readtxt("todo.txt")
    done_mark = contant_todo[int(sys.argv[2])-1]
    del contant_todo[int(sys.argv[2])-1]
    updated = open('todo.txt', "w+")
    for i in contant_todo:
        updated.write(i)
    updated.close()
    return done_mark
#This functions delets one todo item at a time using indexes
def del_todo(): 
    try:
        if int(sys.argv[2]) == 0:
            sys.stdout.write("Error: todo #0 does not exist. Nothing deleted.")
        else:
            del_temp()
            sys.stdout.write("Deleted todo #{}".format(sys.argv[2]))
    except IndexError:
        try:
            sys.stdout.write("Error: todo #{} does not exist. Nothing deleted.".format(sys.argv[2]))
        except:
            sys.stdout.write("Error: Missing NUMBER for deleting todo.")
#This function moves the todo item from 'todo.txt' to 'done.txt' 
def done_todo():
    try:
        if int(sys.argv[2]) == 0:
            sys.stdout.write("Error: todo #0 does not exist.")
        done_marked = del_temp()
        donefile = open("done.txt", "a")
        donefile.write(done_marked)
        donefile.close()
        sys.stdout.write("Marked todo #{} as done.".format(sys.argv[2]))
    except IndexError:
        sys.stdout.write("Error: Missing NUMBER for marking todo as done.")
#This function basically generates the status of pending and done todo items 
def report_todo(): 
    current_time = datetime.date(datetime.now())
    contant_todo = readtxt("todo.txt")
    donefile = open("done.txt", "r+")
    contant_done = readtxt("done.txt")
    pen = len(contant_todo)
    com = len(contant_done)
    sys.stdout.write("{} Pending : {} Completed : {}".format(current_time,pen,com))
#This function displays the various command this todo app can take 
def help_todo(): 
    help_message ="""Usage :-
    $ ./todo add \"todo item\"  #Add a new todo
    $ ./todo ls               #Show remaining todos
    $ ./todo del NUMBER       #Delete a todo
    $ ./todo done NUMBER      #Complete a todo
    $ ./todo help             #Show usage
    $ ./todo report           #Statistics"""
    sys.stdout.write(help_message)