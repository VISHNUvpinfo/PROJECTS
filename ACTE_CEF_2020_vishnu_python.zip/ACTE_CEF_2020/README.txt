Please do not delete 'command_pallet.py' as that contains all the functions for todo appto work properly
and I am using python for execution if not working use python3 interperator
During test cases 1(prints help),2(prints help), 6(print in reverse order) there are some illegal ascii characters are printing I tried many ways for removing it but I came up empty
but my code is corrent due to those illega string my test cases are failling kindly do check that
Anyhow I managed to pass all the test cases in my pc if failing in you pc.Please do check.Thank You!!
DONE BY "vishnuvpinfo@gmail.com" - Vishnu P - 9445693328